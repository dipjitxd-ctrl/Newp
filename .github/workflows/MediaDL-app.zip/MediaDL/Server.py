#!/usr/bin/env python3
"""
Media DL server for Termux  ->  http://127.0.0.1:5000

Setup (once):
    pkg install python ffmpeg
    pip install flask yt-dlp
    termux-setup-storage
Run:
    termux-wake-lock
    python Server.py
Update when a site breaks:
    pip install -U yt-dlp
"""
import glob
import os
import re
import shutil
import subprocess
import threading
import uuid

from flask import Flask, jsonify, request
import yt_dlp

app = Flask(__name__)

# ---- where files are saved ----
def pick_dir():
    for base in ("/sdcard/Download", os.path.expanduser("~/storage/downloads")):
        if os.path.isdir(base) and os.access(base, os.W_OK):
            return os.path.join(base, "MediaDL")
    return os.path.expanduser("~/MediaDL")

DL_DIR = pick_dir()
os.makedirs(DL_DIR, exist_ok=True)
HAS_FFMPEG = shutil.which("ffmpeg") is not None
jobs = {}


def sanitize(name):
    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "", name or "")
    return name.strip().strip(".")[:150]


def unique(base):
    n, i = base, 1
    while glob.glob(os.path.join(glob.escape(DL_DIR), glob.escape(n) + ".*")):
        n = f"{base} ({i})"
        i += 1
    return n


@app.route("/ping")
def ping():
    return jsonify(ok=True, ffmpeg=HAS_FFMPEG, dir=DL_DIR)


@app.route("/info", methods=["POST"])
def info():
    url = (request.get_json(force=True) or {}).get("url", "")
    try:
        with yt_dlp.YoutubeDL({"quiet": True, "noplaylist": True,
                               "skip_download": True}) as ydl:
            d = ydl.extract_info(url, download=False)
        heights = sorted({f["height"] for f in d.get("formats", [])
                          if f.get("height") and f.get("vcodec") not in (None, "none")},
                         reverse=True)
        return jsonify(title=d.get("title", ""), heights=heights,
                       thumbnail=d.get("thumbnail", ""))
    except Exception as e:
        return jsonify(error=str(e)[:300]), 400


def worker(jid, url, name, kind, fmt, q):
    job = jobs[jid]
    try:
        if not name:
            with yt_dlp.YoutubeDL({"quiet": True, "noplaylist": True}) as y:
                name = y.extract_info(url, download=False).get("title", "download")
        base = unique(sanitize(name) or "download")
        job["status"] = "downloading"

        def hook(d):
            if d["status"] == "downloading":
                tot = d.get("total_bytes") or d.get("total_bytes_estimate")
                if tot:
                    job["percent"] = int(d["downloaded_bytes"] * 100 / tot)
            elif d["status"] == "finished":
                job["percent"] = 100
                job["status"] = "processing"

        opts = {"quiet": True, "noplaylist": True, "progress_hooks": [hook],
                "outtmpl": os.path.join(DL_DIR, base + ".%(ext)s"),
                "concurrent_fragment_downloads": 3}

        if kind == "video":
            h = f"[height<={q}]" if q else ""
            if HAS_FFMPEG:
                opts["format"] = (f"bv*{h}[ext=mp4]+ba[ext=m4a]/b{h}[ext=mp4]/"
                                  f"bv*{h}+ba/b{h}/b")
                opts["merge_output_format"] = "mp4"
            else:
                opts["format"] = f"b{h}[ext=mp4]/b{h}/b"
        else:
            if fmt == "mp3" and not HAS_FFMPEG:
                raise RuntimeError("mp3 needs ffmpeg: pkg install ffmpeg")
            opts["format"] = f"ba[ext=m4a][abr<={q}]/ba[ext=m4a]/ba/b"
            if HAS_FFMPEG:
                opts["postprocessors"] = [{"key": "FFmpegExtractAudio",
                                           "preferredcodec": fmt,
                                           "preferredquality": str(q)}]

        with yt_dlp.YoutubeDL(opts) as ydl:
            d = ydl.extract_info(url, download=True)

        rd = d.get("requested_downloads") or []
        path = rd[0].get("filepath") if rd else None
        if not path or not os.path.exists(path):
            c = glob.glob(os.path.join(glob.escape(DL_DIR), glob.escape(base) + ".*"))
            path = c[0] if c else None
        job["file"] = os.path.basename(path) if path else base
        if path and shutil.which("termux-media-scan"):
            subprocess.run(["termux-media-scan", path], timeout=20,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        job["percent"] = 100
        job["status"] = "done"
    except Exception as e:
        job["status"] = "error"
        job["error"] = re.sub(r"\x1b\[[0-9;]*m", "", str(e))[:300]


@app.route("/download", methods=["POST"])
def download():
    j = request.get_json(force=True) or {}
    url = j.get("url")
    if not url:
        return jsonify(error="no url"), 400
    jid = uuid.uuid4().hex[:8]
    jobs[jid] = {"status": "queued", "percent": 0, "file": "", "error": ""}
    threading.Thread(target=worker, daemon=True, args=(
        jid, url, j.get("name", ""), j.get("kind", "video"),
        j.get("format", "mp4"), int(j.get("quality") or 0))).start()
    return jsonify(id=jid)


@app.route("/status/<jid>")
def status(jid):
    return jsonify(jobs.get(jid, {"status": "error", "error": "unknown job"}))


if __name__ == "__main__":
    print(f"Saving to: {DL_DIR}\nffmpeg: {HAS_FFMPEG}")
    app.run(host="127.0.0.1", port=5000, threaded=True)
