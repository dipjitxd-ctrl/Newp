# Media DL
1. Push this folder to a GitHub repo (main branch). Actions builds the APK -> Actions tab -> run -> Artifacts -> MediaDL-apk.
2. Install the APK. It has no launcher icon; it only appears in the Share sheet (Share > More > Media DL).
3. In Termux: pkg install python ffmpeg && pip install flask yt-dlp && termux-setup-storage && python Server.py
Files save to /sdcard/Download/MediaDL
