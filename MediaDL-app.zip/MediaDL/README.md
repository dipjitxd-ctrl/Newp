# Media DL 2.0
Native Android app (Kotlin + Compose). Everything runs on the phone - no server.
1. Upload MediaDL-app.zip to your GitHub repo (the existing build workflow unzips it). Download the APK from Actions > Artifacts.
2. Uninstall the old Media DL first (new signing key), then install the new APK.
3. Open the app once -> "Install & continue" downloads the latest yt-dlp and prepares ffmpeg.
4. Paste links in the app, or Share > Media DL from any app. Videos -> Movies, audio -> Music.
