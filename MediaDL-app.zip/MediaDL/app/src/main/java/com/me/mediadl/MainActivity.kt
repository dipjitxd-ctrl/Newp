package com.me.mediadl

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { Root() } }
    }
}

@Composable
private fun Root() {
    if (!Prefs.setupDone) {
        SetupScreen()
        return
    }
    val ctx = LocalContext.current
    LaunchedEffect(Unit) {
        try { Engine.ensure(ctx.applicationContext) } catch (e: Exception) { /* shown when used */ }
    }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val tasks by Core.tasks.collectAsState()
    val activeCount = tasks.count { it.active }
    val labels = listOf("Download", "Tools", "Queue", "Settings")
    val icons = listOf(Icons.Default.Home, Icons.Default.Build, Icons.Default.List, Icons.Default.Settings)

    Scaffold(
        bottomBar = {
            NavigationBar {
                labels.forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = {
                            if (i == 2 && activeCount > 0) {
                                BadgedBox(badge = { Badge { Text("$activeCount") } }) { Icon(icons[i], label) }
                            } else {
                                Icon(icons[i], label)
                            }
                        },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).imePadding()) {
            Crossfade(targetState = tab, label = "tabs") { t ->
                when (t) {
                    0 -> DownloadScreen(onQueued = { tab = 2 })
                    1 -> ToolsScreen(onQueued = { tab = 2 })
                    2 -> QueueScreen()
                    else -> SettingsScreen()
                }
            }
        }
    }
}
