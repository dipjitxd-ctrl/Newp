package com.me.mediadl

import android.content.Context
import java.io.File
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/** Runs the ffmpeg binary that ships with the engine, tuned to the device profile. */
object Ffmpeg {
    val AUDIO_EXTS = setOf("mp3", "m4a", "wav", "flac")

    private var bin: File? = null
    private var libs = ""
    private var encoders: String? = null
    private val procs = ConcurrentHashMap<String, Process>()

    fun locate(ctx: Context): Boolean {
        bin?.let { if (it.exists()) return true }
        val nat = File(ctx.applicationInfo.nativeLibraryDir)
        var b = File(nat, "libffmpeg.so")
        if (!b.exists()) {
            b = nat.listFiles()?.firstOrNull { it.name.contains("ffmpeg") && !it.name.contains("zip") }
                ?: return false
        }
        val dirs = ArrayList<String>()
        dirs.add(nat.absolutePath)
        try {
            ctx.noBackupFilesDir.walkTopDown().maxDepth(10)
                .filter { it.isDirectory && it.name == "lib" && it.absolutePath.contains("ffmpeg") }
                .forEach { dirs.add(it.absolutePath) }
        } catch (e: Exception) { /* ignore */ }
        bin = b
        libs = dirs.joinToString(":")
        return true
    }

    fun diag(ctx: Context): String =
        if (locate(ctx)) "ffmpeg ready (${bin?.name})" else "ffmpeg not found — try re-running setup"

    private fun env(pb: ProcessBuilder) {
        val old = pb.environment()["LD_LIBRARY_PATH"]
        pb.environment()["LD_LIBRARY_PATH"] = if (old.isNullOrEmpty()) libs else "$libs:$old"
    }

    fun hasEncoder(ctx: Context, name: String): Boolean {
        if (encoders == null) {
            encoders = try {
                if (!locate(ctx)) "" else {
                    val pb = ProcessBuilder(bin!!.absolutePath, "-hide_banner", "-encoders")
                    env(pb)
                    pb.redirectErrorStream(true)
                    val p = pb.start()
                    val t = p.inputStream.bufferedReader().readText()
                    p.waitFor()
                    t
                }
            } catch (e: Exception) { "" }
        }
        return encoders!!.contains(" $name ")
    }

    fun buildArgs(
        ctx: Context, inp: String, out: String, ext: String,
        compress: Boolean, level: Int, kbps: Int
    ): List<String> {
        val p = Device.profile()
        val a = ArrayList<String>()
        a += listOf("-i", inp)
        if (ext in AUDIO_EXTS) {
            a += "-vn"
            a += when (ext) {
                "mp3" -> listOf("-c:a", "libmp3lame", "-b:a", "${kbps}k")
                "wav" -> listOf("-c:a", "pcm_s16le")
                "flac" -> listOf("-c:a", "flac")
                else -> listOf("-c:a", "aac", "-b:a", "${kbps}k")
            }
            a += listOf("-threads", p.threads.toString())
        } else {
            val crf = if (compress) when (level) { 0 -> 26; 1 -> 28; else -> 31 } else 23
            val maxH = if (compress) when (level) { 0 -> 1080; 1 -> 720; else -> 480 } else 0
            a += listOf("-map", "0:v:0", "-map", "0:a:0?")
            a += listOf(
                "-vf",
                if (maxH > 0) "scale=-2:'min($maxH,ih)'" else "scale=trunc(iw/2)*2:trunc(ih/2)*2"
            )
            if (hasEncoder(ctx, "libx264")) {
                a += listOf("-c:v", "libx264", "-preset", p.preset, "-crf", crf.toString(), "-pix_fmt", "yuv420p")
                if (p.x264.isNotEmpty()) a += listOf("-x264-params", p.x264)
            } else {
                a += listOf("-c:v", "mpeg4", "-q:v", if (compress) (when (level) { 0 -> "4"; 1 -> "6"; else -> "9" }) else "3")
            }
            a += listOf("-c:a", "aac", "-b:a", if (compress && level == 2) "64k" else "128k")
            if (ext == "mp4") a += listOf("-movflags", "+faststart")
            a += listOf("-threads", p.threads.toString())
        }
        a += out
        return a
    }

    fun kill(id: String) {
        procs[id]?.destroy()
    }

    fun run(ctx: Context, id: String, args: List<String>, totalMs: Long, onProgress: (Float) -> Unit) {
        if (!locate(ctx)) throw IOException("ffmpeg engine not found. Re-run setup in Settings.")
        val cmd = ArrayList<String>()
        cmd += bin!!.absolutePath
        cmd += listOf("-y", "-hide_banner", "-loglevel", "error", "-nostats", "-progress", "pipe:1")
        cmd += args
        val pb = ProcessBuilder(cmd)
        env(pb)
        val p = pb.start()
        procs[id] = p
        val err = StringBuilder()
        val th = Thread {
            try {
                p.errorStream.bufferedReader().forEachLine {
                    if (err.length < 3000) err.append(it).append('\n')
                }
            } catch (e: Exception) { /* ignore */ }
        }
        th.start()
        try {
            p.inputStream.bufferedReader().forEachLine { l ->
                if (totalMs > 0 && (l.startsWith("out_time_us=") || l.startsWith("out_time_ms="))) {
                    val us = l.substringAfter('=').trim().toLongOrNull()
                    if (us != null) onProgress((us / 1000f / totalMs).coerceIn(0f, 1f))
                }
            }
            val code = p.waitFor()
            th.join(1000)
            if (code != 0) {
                val msg = err.toString().trim().lines().lastOrNull().orEmpty()
                throw IOException(msg.ifBlank { "ffmpeg failed ($code)" })
            }
        } finally {
            procs.remove(id)
            p.destroy()
        }
    }
}
