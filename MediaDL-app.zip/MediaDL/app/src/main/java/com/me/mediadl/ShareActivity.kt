package com.me.mediadl

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** Floating window shown on top of the app you shared from. */
class ShareActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = Util.extractUrl(intent?.getStringExtra(Intent.EXTRA_TEXT) ?: "")
        if (url == null) {
            Toast.makeText(this, "No link found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        setContent { AppTheme { ShareWindow(url) { finish() } } }
    }
}

@Composable
private fun ShareWindow(url: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var taskId by remember { mutableStateOf<String?>(null) }
    val tasks by Core.tasks.collectAsState()
    val task = tasks.firstOrNull { it.id == taskId }
    val maxH = (LocalConfiguration.current.screenHeightDp * 0.86f).dp
    val none = remember { MutableInteractionSource() }

    Box(
        Modifier.fillMaxSize().background(Color(0x99000000))
            .clickable(interactionSource = none, indication = null) { onClose() }
            .imePadding(),
        contentAlignment = Alignment.Center
    ) {
        Card(
            Modifier.fillMaxWidth(0.92f).heightIn(max = maxH)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
            shape = MaterialTheme.shapes.large,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
        ) {
            Column {
                Row(
                    Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primary).padding(start = 20.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Download", color = MaterialTheme.colorScheme.onPrimary,
                        style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.Close, "Close", tint = MaterialTheme.colorScheme.onPrimary)
                    }
                }
                Column(
                    Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    when {
                        !Prefs.setupDone -> {
                            Text("Finish the one-time setup first.", fontWeight = FontWeight.SemiBold)
                            Text(
                                "Open Media DL once so it can download its engine, then share again.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Button(
                                onClick = {
                                    ctx.startActivity(Intent(ctx, MainActivity::class.java))
                                    onClose()
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Open Media DL") }
                        }
                        task == null -> DownloadPanel(url = url, key = 1) { taskId = it }
                        else -> {
                            TaskRow(task)
                            if (task.active) {
                                Text(
                                    "You can close this window — it keeps going in the background.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                TextButton(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("Hide") }
                            } else {
                                Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("Close") }
                            }
                        }
                    }
                }
            }
        }
    }
}
