package com.me.mediadl

enum class TaskStatus { QUEUED, RUNNING, DONE, ERROR, CANCELED }
enum class TaskKind { DOWNLOAD, CONVERT }
enum class ConvMode { CONVERT, COMPRESS }

data class Task(
    val id: String,
    val kind: TaskKind,
    val title: String,
    val thumb: String = "",
    val audio: Boolean = false,
    val status: TaskStatus = TaskStatus.QUEUED,
    val progress: Float = 0f,          // < 0 means "unknown / indeterminate"
    val note: String = "",
    val outName: String = "",
    val outUri: String = "",
    val error: String = "",
    val time: Long = System.currentTimeMillis()
) {
    val active: Boolean get() = status == TaskStatus.QUEUED || status == TaskStatus.RUNNING
}

data class MediaInfo(
    val url: String,
    val title: String,
    val thumb: String,
    val durationSec: Int,
    val heights: List<Int>
)

data class DlOptions(
    val audio: Boolean,
    val height: Int,        // 0 = best
    val audioFmt: String,   // m4a | mp3
    val kbps: Int,
    val compress: Boolean,
    val name: String
)

data class ConvOptions(
    val mode: ConvMode,
    val ext: String,        // target extension for CONVERT
    val level: Int,         // compress level 0 light, 1 balanced, 2 strong
    val kbps: Int,
    val name: String
)
