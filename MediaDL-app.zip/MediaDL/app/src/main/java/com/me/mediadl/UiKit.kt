package com.me.mediadl

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

@Composable
fun Card2(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
    }
}

@Composable
fun SectionTitle(t: String) {
    Text(t, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
}

@Composable
fun Picker(label: String, items: List<String>, index: Int, onPick: (Int) -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(
            onClick = { open = true },
            modifier = Modifier.fillMaxWidth().height(60.dp),
            shape = MaterialTheme.shapes.medium
        ) {
            Column(Modifier.weight(1f)) {
                Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(items.getOrElse(index) { "" }, color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.Default.ArrowDropDown, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            items.forEachIndexed { i, s ->
                DropdownMenuItem(text = { Text(s) }, onClick = { open = false; onPick(i) })
            }
        }
    }
}

@Composable
fun ChipRow(items: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEachIndexed { i, s ->
            FilterChip(selected = i == selected, onClick = { onSelect(i) }, label = { Text(s) })
        }
    }
}

@Composable
fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

// ---------------- task row (queue + share window) ----------------

@Composable
fun TaskRow(t: Task) {
    val ctx = LocalContext.current
    Card(
        Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.size(56.dp).clip(MaterialTheme.shapes.medium).background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                if (t.thumb.isNotBlank()) {
                    AsyncImage(model = t.thumb, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Text(if (t.audio) "♪" else "▶", color = MaterialTheme.colorScheme.onPrimaryContainer, fontSize = 22.sp)
                }
            }
            Column(Modifier.weight(1f)) {
                Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(2.dp))
                when (t.status) {
                    TaskStatus.QUEUED -> Text("Waiting…", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    TaskStatus.RUNNING -> {
                        Text(t.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(6.dp))
                        if (t.progress < 0f) LinearProgressIndicator(Modifier.fillMaxWidth())
                        else LinearProgressIndicator(progress = { t.progress }, modifier = Modifier.fillMaxWidth())
                    }
                    TaskStatus.DONE -> Text("✓ ${t.outName}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    TaskStatus.ERROR -> Text(t.error, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    TaskStatus.CANCELED -> Text("Canceled", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Row {
                when {
                    t.active -> IconButton(onClick = { Core.cancel(t.id) }, Modifier.size(40.dp)) { Icon(Icons.Default.Close, "Cancel") }
                    t.status == TaskStatus.DONE -> {
                        IconButton(onClick = { Util.open(ctx, t) }, Modifier.size(40.dp)) { Icon(Icons.Default.PlayArrow, "Open") }
                        IconButton(onClick = { Util.share(ctx, t) }, Modifier.size(40.dp)) { Icon(Icons.Default.Share, "Share") }
                    }
                    else -> {
                        if (Core.canRetry(t.id)) IconButton(onClick = { Core.retry(t.id) }, Modifier.size(40.dp)) { Icon(Icons.Default.Refresh, "Retry") }
                        IconButton(onClick = { Core.remove(t.id) }, Modifier.size(40.dp)) { Icon(Icons.Default.Delete, "Remove") }
                    }
                }
            }
        }
    }
}

// ---------------- download panel (used in app + share window) ----------------

@Composable
fun DownloadPanel(url: String, key: Int, onQueued: (String) -> Unit) {
    val ctx = LocalContext.current
    var loading by remember(key) { mutableStateOf(true) }
    var err by remember(key) { mutableStateOf<String?>(null) }
    var info by remember(key) { mutableStateOf<MediaInfo?>(null) }

    LaunchedEffect(key) {
        loading = true
        err = null
        try {
            info = Engine.info(ctx.applicationContext, url)
        } catch (e: Exception) {
            err = Util.friendly(e)
        }
        loading = false
    }

    val i = info
    val e = err
    when {
        loading -> Row(
            Modifier.fillMaxWidth().padding(vertical = 24.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.5.dp)
            Spacer(Modifier.width(12.dp))
            Text("Reading link…", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        e != null -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Couldn't read this link", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.error)
            Text(e, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                "Tip: if a site stopped working, update yt-dlp in Settings.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        i != null -> PanelOptions(i, onQueued)
    }
}

@Composable
private fun PanelOptions(info: MediaInfo, onQueued: (String) -> Unit) {
    var audio by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf(Util.cleanName(info.title)) }
    val heights = remember(info) { listOf(0) + info.heights }
    var hIdx by remember(info) { mutableIntStateOf(Util.pickHeight(heights, Prefs.defVideoH)) }
    val fmts = listOf("m4a", "mp3")
    var fIdx by remember { mutableIntStateOf(fmts.indexOf(Prefs.defAudioFmt).coerceAtLeast(0)) }
    val rates = Util.RATES
    var kIdx by remember { mutableIntStateOf(rates.indexOf(Prefs.defAudioK).let { if (it < 0) 2 else it }) }
    var compress by remember { mutableStateOf(Prefs.defCompress) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AsyncImage(
                model = info.thumb, contentDescription = null,
                modifier = Modifier.width(120.dp).height(68.dp).clip(MaterialTheme.shapes.medium)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentScale = ContentScale.Crop
            )
            Column(Modifier.weight(1f)) {
                Text(info.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                val d = Util.dur(info.durationSec)
                if (d.isNotEmpty()) Text(d, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        OutlinedTextField(
            value = name, onValueChange = { name = it },
            label = { Text("File name") },
            modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.medium, maxLines = 3
        )
        ChipRow(listOf("Video", "Audio"), if (audio) 1 else 0) { audio = it == 1 }
        if (!audio) {
            Picker("Quality", heights.map { if (it == 0) "Best available" else "${it}p" }, hIdx, { hIdx = it })
            SwitchRow("Compress", "Smaller file · max 720p · done on your phone", compress) { compress = it }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Picker("Format", fmts.map { it.uppercase() }, fIdx, { fIdx = it }, Modifier.weight(1f))
                Picker("Bitrate", rates.map { "$it kbps" }, kIdx, { kIdx = it }, Modifier.weight(1f))
            }
        }
        androidx.compose.material3.Button(
            onClick = {
                val id = Core.enqueueDownload(
                    info,
                    DlOptions(audio, heights[hIdx], fmts[fIdx], rates[kIdx], compress && !audio, name)
                )
                onQueued(id)
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = MaterialTheme.shapes.medium
        ) { Text("Download", fontWeight = FontWeight.SemiBold) }
    }
}
