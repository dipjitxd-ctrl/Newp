package com.me.mediadl

import android.content.Context
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** Wraps yt-dlp + ffmpeg + aria2c (the "engine"). */
object Engine {
    enum class S { IDLE, WORKING, READY, FAILED }

    val state = MutableStateFlow(S.IDLE)
    val step = MutableStateFlow("")
    val error = MutableStateFlow("")

    @Volatile
    var inited = false
        private set

    private val mutex = Mutex()

    private fun initParts(ctx: Context, report: (String) -> Unit) {
        report("Preparing runtime…")
        YoutubeDL.getInstance().init(ctx)
        report("Preparing ffmpeg…")
        FFmpeg.getInstance().init(ctx)
        report("Preparing fast downloader…")
        try { Aria2c.getInstance().init(ctx) } catch (e: Exception) { /* optional */ }
        Ffmpeg.locate(ctx)
    }

    suspend fun ensure(ctx: Context) {
        if (inited) return
        mutex.withLock {
            if (inited) return
            withContext(Dispatchers.IO) { initParts(ctx) { } }
            inited = true
            state.value = S.READY
        }
    }

    /** First-run setup: prepare everything and download the latest yt-dlp. */
    suspend fun setup(ctx: Context) {
        state.value = S.WORKING
        error.value = ""
        try {
            mutex.withLock {
                if (!inited) {
                    withContext(Dispatchers.IO) { initParts(ctx) { step.value = it } }
                    inited = true
                }
            }
            step.value = "Downloading latest yt-dlp…"
            withContext(Dispatchers.IO) {
                YoutubeDL.getInstance().updateYoutubeDL(ctx, YoutubeDL.UpdateChannel.STABLE)
            }
            step.value = "All set"
            state.value = S.READY
            Prefs.markSetupDone(true)
        } catch (e: Exception) {
            error.value = Util.friendly(e)
            state.value = S.FAILED
        }
    }

    /** Lets the user continue when the download failed but the bundled engine works. */
    fun skipUpdate() {
        if (inited) {
            state.value = S.READY
            Prefs.markSetupDone(true)
        }
    }

    suspend fun update(ctx: Context): String = withContext(Dispatchers.IO) {
        ensure(ctx)
        val st = YoutubeDL.getInstance().updateYoutubeDL(ctx, YoutubeDL.UpdateChannel.STABLE)
        val s = st?.toString() ?: ""
        if (s.contains("ALREADY", true)) "Already up to date" else "Updated to the latest yt-dlp"
    }

    suspend fun info(ctx: Context, url: String): MediaInfo = withContext(Dispatchers.IO) {
        ensure(ctx)
        val req = YoutubeDLRequest(url)
        req.addOption("--no-playlist")
        req.addOption("--socket-timeout", "15")
        val i = YoutubeDL.getInstance().getInfo(req)
        val hs = ArrayList<Int>()
        for (f in (i.formats ?: emptyList())) {
            val h = f.height ?: 0
            val vc = f.vcodec ?: ""
            if (h > 0 && vc != "none") hs.add(h)
        }
        MediaInfo(
            url = url,
            title = i.title ?: "video",
            thumb = i.thumbnail ?: "",
            durationSec = i.duration ?: 0,
            heights = hs.distinct().sortedDescending()
        )
    }
}
