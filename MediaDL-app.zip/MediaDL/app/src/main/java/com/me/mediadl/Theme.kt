package com.me.mediadl

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColors = lightColorScheme(
    primary = Color(0xFF2563EB), onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE7FF), onPrimaryContainer = Color(0xFF0B2A6B),
    secondaryContainer = Color(0xFFE3EBFF), onSecondaryContainer = Color(0xFF0B2A6B),
    background = Color(0xFFF6F8FD), onBackground = Color(0xFF12161C),
    surface = Color.White, onSurface = Color(0xFF12161C),
    surfaceVariant = Color(0xFFEAEFF8), onSurfaceVariant = Color(0xFF4A5565),
    outline = Color(0xFFC3CCDA), error = Color(0xFFD93025)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8AB4FF), onPrimary = Color(0xFF06214F),
    primaryContainer = Color(0xFF1B3A7A), onPrimaryContainer = Color(0xFFDCE7FF),
    secondaryContainer = Color(0xFF1E2A44), onSecondaryContainer = Color(0xFFDCE7FF),
    background = Color(0xFF0D1117), onBackground = Color(0xFFE6EAF2),
    surface = Color(0xFF151B24), onSurface = Color(0xFFE6EAF2),
    surfaceVariant = Color(0xFF1E2633), onSurfaceVariant = Color(0xFFA9B4C6),
    outline = Color(0xFF3A465A), error = Color(0xFFFF8A80)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = when (Prefs.theme) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        shapes = Shapes(
            small = RoundedCornerShape(10.dp),
            medium = RoundedCornerShape(16.dp),
            large = RoundedCornerShape(22.dp)
        ),
        content = content
    )
}
