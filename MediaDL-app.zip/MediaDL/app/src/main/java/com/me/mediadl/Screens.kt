package com.me.mediadl

import android.Manifest
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

// =====================================================================
// First-run setup
// =====================================================================
@Composable
fun SetupScreen() {
    val ctx = LocalContext.current
    val st by Engine.state.collectAsState()
    val step by Engine.step.collectAsState()
    val err by Engine.error.collectAsState()
    val scope = rememberCoroutineScope()

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        scope.launch { Engine.setup(ctx.applicationContext) }
    }

    fun start() {
        val p = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT <= 28) p.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (p.isEmpty()) scope.launch { Engine.setup(ctx.applicationContext) }
        else permLauncher.launch(p.toTypedArray())
    }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(Modifier.height(32.dp))
        Box(
            Modifier.size(84.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center
        ) { Text("⬇", color = MaterialTheme.colorScheme.onPrimary, fontSize = 38.sp) }
        Spacer(Modifier.height(20.dp))
        Text("Welcome to Media DL", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "One quick setup. The app downloads the latest download engine (yt-dlp) and prepares ffmpeg on this phone. Needs internet.",
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))
        Card2 {
            SetupLine("Runtime & ffmpeg", "Converts and compresses locally")
            SetupLine("yt-dlp (latest)", "Supports hundreds of sites")
            SetupLine("Notifications", "Shows progress while you use other apps")
        }
        Spacer(Modifier.height(20.dp))
        if (st == Engine.S.WORKING) {
            LinearProgressIndicator(Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Text(step, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (err.isNotEmpty()) {
            Text("Setup problem: $err", color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
        }
        Button(
            onClick = { start() },
            enabled = st != Engine.S.WORKING,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = MaterialTheme.shapes.medium
        ) { Text(if (st == Engine.S.FAILED) "Try again" else "Install & continue", fontWeight = FontWeight.SemiBold) }
        if (st == Engine.S.FAILED && Engine.inited) {
            TextButton(onClick = { Engine.skipUpdate() }) { Text("Continue anyway (use built-in engine)") }
        }
    }
}

@Composable
private fun SetupLine(title: String, sub: String) {
    Column {
        Text(title, fontWeight = FontWeight.SemiBold)
        Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// =====================================================================
// Download tab
// =====================================================================
@Composable
fun DownloadScreen(onQueued: () -> Unit) {
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    var link by rememberSaveable { mutableStateOf("") }
    var key by rememberSaveable { mutableIntStateOf(0) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Column {
            Text("Media DL", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Paste a link, or use Share → Media DL from any app", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Card2 {
            OutlinedTextField(
                value = link, onValueChange = { link = it; key = 0 },
                label = { Text("Video or audio link") },
                modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.medium, maxLines = 3
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = {
                        val t = clip.getText()?.text ?: ""
                        if (t.isBlank()) Toast.makeText(ctx, "Clipboard is empty", Toast.LENGTH_SHORT).show()
                        else { link = Util.extractUrl(t) ?: t; key = 0 }
                    },
                    modifier = Modifier.weight(1f).height(48.dp), shape = MaterialTheme.shapes.medium
                ) { Text("Paste") }
                Button(
                    onClick = {
                        val u = Util.extractUrl(link)
                        if (u == null) Toast.makeText(ctx, "That doesn't look like a link", Toast.LENGTH_SHORT).show()
                        else { link = u; key += 1 }
                    },
                    enabled = link.isNotBlank(),
                    modifier = Modifier.weight(1f).height(48.dp), shape = MaterialTheme.shapes.medium
                ) { Text("Analyze") }
            }
        }
        if (key > 0) {
            Card2 {
                DownloadPanel(url = link.trim(), key = key) {
                    Toast.makeText(ctx, "Added to Queue", Toast.LENGTH_SHORT).show()
                    link = ""; key = 0
                    onQueued()
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

// =====================================================================
// Tools tab (local convert / compress)
// =====================================================================
@Composable
fun ToolsScreen(onQueued: () -> Unit) {
    val ctx = LocalContext.current
    var uri by remember { mutableStateOf<Uri?>(null) }
    var fname by remember { mutableStateOf("") }
    var fsize by remember { mutableLongStateOf(0L) }
    var isAudio by remember { mutableStateOf(false) }
    var mode by remember { mutableIntStateOf(0) }
    var tIdx by remember { mutableIntStateOf(0) }
    var kIdx by remember { mutableIntStateOf(2) }
    var lvl by remember { mutableIntStateOf(1) }
    var outName by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? ->
        if (u != null) {
            var n = "file"
            var s = 0L
            try {
                ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val si = c.getColumnIndex(OpenableColumns.SIZE)
                        if (ni >= 0) n = c.getString(ni) ?: n
                        if (si >= 0) s = c.getLong(si)
                    }
                }
            } catch (e: Exception) { /* ignore */ }
            uri = u
            fname = n
            fsize = s
            isAudio = (ctx.contentResolver.getType(u) ?: "").startsWith("audio")
            tIdx = 0
            outName = n.substringBeforeLast('.')
        }
    }

    val targets = if (isAudio) listOf("mp3", "m4a", "wav", "flac") else listOf("mp4", "mkv", "mp3", "m4a", "wav", "flac")
    val target = targets[tIdx.coerceIn(0, targets.size - 1)]
    val showBitrate = (mode == 0 && (target == "mp3" || target == "m4a")) || (mode == 1 && isAudio)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Column {
            Text("Tools", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Convert or compress files on your phone", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Card2 {
            Button(
                onClick = { picker.launch(arrayOf("video/*", "audio/*")) },
                modifier = Modifier.fillMaxWidth().height(52.dp), shape = MaterialTheme.shapes.medium
            ) { Text(if (uri == null) "Choose a video or audio file" else "Choose another file") }
            if (uri != null) {
                Text(fname, fontWeight = FontWeight.SemiBold, maxLines = 2)
                val sz = Util.humanSize(fsize)
                if (sz.isNotEmpty()) Text(sz + if (isAudio) " · audio" else " · video", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (uri != null) {
            Card2 {
                ChipRow(listOf("Convert", "Compress"), mode) { mode = it }
                if (mode == 0) {
                    Picker("Output format", targets.map { it.uppercase() }, tIdx.coerceIn(0, targets.size - 1), { tIdx = it })
                    Text(
                        "Pick MP3 / M4A to pull the audio out of a video.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else if (!isAudio) {
                    Picker("Compression", listOf("Light · up to 1080p", "Balanced · 720p", "Strong · 480p"), lvl, { lvl = it })
                }
                if (showBitrate) Picker("Bitrate", Util.RATES.map { "$it kbps" }, kIdx, { kIdx = it })
                OutlinedTextField(
                    value = outName, onValueChange = { outName = it },
                    label = { Text("Output name") },
                    modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.medium, maxLines = 2
                )
                Text(
                    Device.describe().lines().first() + " — tuned automatically for this phone.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(
                    onClick = {
                        Core.enqueueConvert(
                            uri!!,
                            ConvOptions(
                                if (mode == 0) ConvMode.CONVERT else ConvMode.COMPRESS,
                                target, lvl, Util.RATES[kIdx], outName
                            ),
                            fname
                        )
                        Toast.makeText(ctx, "Added to Queue", Toast.LENGTH_SHORT).show()
                        uri = null
                        onQueued()
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp), shape = MaterialTheme.shapes.medium
                ) { Text(if (mode == 0) "Convert" else "Compress", fontWeight = FontWeight.SemiBold) }
            }
        }
    }
}

// =====================================================================
// Queue tab
// =====================================================================
@Composable
fun QueueScreen() {
    val tasks by Core.tasks.collectAsState()
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Queue", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (tasks.any { !it.active }) TextButton(onClick = { Core.clearFinished() }) { Text("Clear finished") }
        }
        if (tasks.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "Nothing here yet.\nDownloads and conversions show up here.",
                    textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(tasks, key = { it.id }) { TaskRow(it) }
            }
        }
    }
}

// =====================================================================
// Settings tab
// =====================================================================
@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        Card2 {
            SectionTitle("Performance")
            ChipRow(listOf("Auto", "Low", "Balanced", "High"), Prefs.perfMode) { Prefs.updatePerf(it) }
            Text(Device.describe(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Tasks at once", fontWeight = FontWeight.Medium)
            ChipRow(listOf("Auto", "1", "2", "3"), Prefs.parallel) { Prefs.updateParallel(it) }
            SwitchRow("Turbo downloader", "Uses aria2 for faster downloads (may not work on every site)", Prefs.turbo) { Prefs.updateTurbo(it) }
        }

        Card2 {
            SectionTitle("Defaults")
            val hs = listOf(0, 1080, 720, 480)
            Picker("Video quality", hs.map { if (it == 0) "Best available" else "${it}p" }, hs.indexOf(Prefs.defVideoH).coerceAtLeast(0), { Prefs.updateDefH(hs[it]) })
            val fm = listOf("m4a", "mp3")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Picker("Audio format", fm.map { it.uppercase() }, fm.indexOf(Prefs.defAudioFmt).coerceAtLeast(0), { Prefs.updateDefFmt(fm[it]) }, Modifier.weight(1f))
                Picker("Bitrate", Util.RATES.map { "$it kbps" }, Util.RATES.indexOf(Prefs.defAudioK).coerceAtLeast(0), { Prefs.updateDefK(Util.RATES[it]) }, Modifier.weight(1f))
            }
            SwitchRow("Compress videos by default", "", Prefs.defCompress) { Prefs.updateDefCompress(it) }
        }

        Card2 {
            SectionTitle("Engine")
            Text(Ffmpeg.diag(ctx), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(
                onClick = {
                    scope.launch {
                        busy = true
                        msg = try { Engine.update(ctx.applicationContext) } catch (e: Exception) { "Failed: " + Util.friendly(e) }
                        busy = false
                    }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(48.dp), shape = MaterialTheme.shapes.medium
            ) { Text(if (busy) "Updating…" else "Update yt-dlp") }
            if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(
                onClick = {
                    val n = Core.clearTemp()
                    Toast.makeText(ctx, if (n < 0) "Tasks are running" else "Temp files cleared", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth().height(48.dp), shape = MaterialTheme.shapes.medium
            ) { Text("Clear temp files") }
        }

        Card2 {
            SectionTitle("Appearance")
            ChipRow(listOf("System", "Light", "Dark"), Prefs.theme) { Prefs.updateTheme(it) }
            Text("Saved to: Movies (video) · Music (audio)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(8.dp))
    }
}
