package com.me.mediadl

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.util.Locale

object Util {
    val RATES = listOf(64, 96, 128, 192, 256, 320)

    private val urlRe = Regex("https?://[^\\s]+")
    private val ansiRe = Regex("\u001B\\[[0-9;]*m")
    private val badChars = Regex("[\\\\/:*?\"<>|\\p{Cntrl}]")

    fun extractUrl(s: String): String? =
        urlRe.find(s)?.value?.trimEnd('.', ',', ')', ']', '"')

    fun cleanName(s: String): String =
        s.replace(badChars, "").trim().trim('.').take(120).ifBlank { "download" }

    fun friendly(e: Throwable): String {
        val raw = (e.message ?: e.javaClass.simpleName).replace(ansiRe, "")
        val lines = raw.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val line = lines.firstOrNull { it.contains("ERROR:") } ?: lines.lastOrNull() ?: raw
        var out = line.substringAfter("ERROR:").trim()
        if (out.contains("Unsupported URL", true)) out = "This link isn't supported"
        return out.take(220).ifBlank { "Something went wrong" }
    }

    fun dur(sec: Int): String {
        if (sec <= 0) return ""
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }

    fun humanSize(b: Long): String = when {
        b <= 0 -> ""
        b < 1_048_576 -> "${b / 1024} KB"
        b < 1_073_741_824 -> String.format(Locale.US, "%.1f MB", b / 1_048_576.0)
        else -> String.format(Locale.US, "%.2f GB", b / 1_073_741_824.0)
    }

    /** heights always starts with 0 (= best). Picks the best one that is <= pref. */
    fun pickHeight(heights: List<Int>, pref: Int): Int {
        if (pref <= 0) return 0
        val i = heights.indexOfFirst { it != 0 && it <= pref }
        return if (i < 0) 0 else i
    }

    fun mimeOf(ext: String): String = when (ext.lowercase()) {
        "mp4", "m4v" -> "video/mp4"
        "mkv" -> "video/x-matroska"
        "webm" -> "video/webm"
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        "aac" -> "audio/aac"
        "wav" -> "audio/x-wav"
        "flac" -> "audio/flac"
        "ogg", "opus" -> "audio/ogg"
        else -> "application/octet-stream"
    }

    fun open(ctx: Context, t: Task) {
        val uri = Uri.parse(t.outUri)
        if (uri.scheme == "file") {
            Toast.makeText(ctx, "Saved at ${uri.path}", Toast.LENGTH_LONG).show(); return
        }
        try {
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, if (t.audio) "audio/*" else "video/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(ctx, "No app found to open this file", Toast.LENGTH_SHORT).show()
        }
    }

    fun share(ctx: Context, t: Task) {
        val uri = Uri.parse(t.outUri)
        if (uri.scheme == "file") {
            Toast.makeText(ctx, "Saved at ${uri.path}", Toast.LENGTH_LONG).show(); return
        }
        try {
            val send = Intent(Intent.ACTION_SEND)
                .setType(if (t.audio) "audio/*" else "video/*")
                .putExtra(Intent.EXTRA_STREAM, uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(ctx, "Can't share this file", Toast.LENGTH_SHORT).show()
        }
    }
}
