package com.me.mediadl

import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Keeps the process alive while tasks run and shows one progress notification. */
class DownloadService : Service() {
    private val sc = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var obs: Job? = null
    private val nid = 4711

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val first = build(Core.tasks.value.filter { it.active })
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(nid, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(nid, first)
        }
        obs?.cancel()
        obs = sc.launch {
            Core.tasks.collect { list ->
                val act = list.filter { it.active }
                if (act.isEmpty()) {
                    ServiceCompat.stopForeground(this@DownloadService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                    stopSelf()
                } else {
                    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    nm.notify(nid, build(act))
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun build(act: List<Task>): android.app.Notification {
        val title = when {
            act.isEmpty() -> "Media DL"
            act.size == 1 -> act[0].title
            else -> "${act.size} tasks running"
        }
        val known = act.filter { it.progress >= 0f }
        val pct = if (known.isEmpty()) 0 else (known.map { it.progress }.average() * 100).toInt()
        return NotificationCompat.Builder(this, Notifier.CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(act.firstOrNull()?.note ?: "Working…")
            .setProgress(100, pct, known.isEmpty())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(Notifier.openApp(this))
            .build()
    }

    override fun onDestroy() {
        sc.cancel()
        super.onDestroy()
    }
}
