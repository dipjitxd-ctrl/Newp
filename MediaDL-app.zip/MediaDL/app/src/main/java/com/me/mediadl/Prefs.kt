package com.me.mediadl

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object Prefs {
    private lateinit var sp: SharedPreferences

    var setupDone by mutableStateOf(false)
        private set
    var perfMode by mutableIntStateOf(0)        // 0 auto, 1 low, 2 balanced, 3 high
        private set
    var parallel by mutableIntStateOf(0)        // 0 auto, else 1..3
        private set
    var turbo by mutableStateOf(false)          // aria2c
        private set
    var theme by mutableIntStateOf(0)           // 0 system, 1 light, 2 dark
        private set
    var defVideoH by mutableIntStateOf(1080)    // 0 = best
        private set
    var defAudioFmt by mutableStateOf("m4a")
        private set
    var defAudioK by mutableIntStateOf(128)
        private set
    var defCompress by mutableStateOf(false)
        private set

    var history: String
        get() = sp.getString("history", "[]") ?: "[]"
        set(v) { sp.edit().putString("history", v).apply() }

    fun init(c: Context) {
        sp = c.getSharedPreferences("mediadl", Context.MODE_PRIVATE)
        setupDone = sp.getBoolean("setup", false)
        perfMode = sp.getInt("perf", 0)
        parallel = sp.getInt("parallel", 0)
        turbo = sp.getBoolean("turbo", false)
        theme = sp.getInt("theme", 0)
        defVideoH = sp.getInt("defH", 1080)
        defAudioFmt = sp.getString("defFmt", "m4a") ?: "m4a"
        defAudioK = sp.getInt("defK", 128)
        defCompress = sp.getBoolean("defCompress", false)
    }

    fun markSetupDone(v: Boolean) { setupDone = v; sp.edit().putBoolean("setup", v).apply() }
    fun updatePerf(v: Int) { perfMode = v; sp.edit().putInt("perf", v).apply() }
    fun updateParallel(v: Int) { parallel = v; sp.edit().putInt("parallel", v).apply() }
    fun updateTurbo(v: Boolean) { turbo = v; sp.edit().putBoolean("turbo", v).apply() }
    fun updateTheme(v: Int) { theme = v; sp.edit().putInt("theme", v).apply() }
    fun updateDefH(v: Int) { defVideoH = v; sp.edit().putInt("defH", v).apply() }
    fun updateDefFmt(v: String) { defAudioFmt = v; sp.edit().putString("defFmt", v).apply() }
    fun updateDefK(v: Int) { defAudioK = v; sp.edit().putInt("defK", v).apply() }
    fun updateDefCompress(v: Boolean) { defCompress = v; sp.edit().putBoolean("defCompress", v).apply() }
}
