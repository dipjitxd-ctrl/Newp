package com.me.mediadl

import android.app.ActivityManager
import android.content.Context

enum class Tier { LOW, MID, HIGH }

data class Profile(
    val tier: Tier,
    val threads: Int,      // ffmpeg threads
    val preset: String,    // x264 preset
    val x264: String,      // extra x264 params (memory/cpu limits)
    val fragments: Int,    // concurrent download fragments
    val parallel: Int      // tasks running at once
)

object Device {
    var cores = 4
    var ramMb = 4096
    var lowRam = false

    fun init(c: Context) {
        try {
            val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            ramMb = (mi.totalMem / 1048576L).toInt()
            lowRam = am.isLowRamDevice
        } catch (e: Exception) { /* keep defaults */ }
        cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
    }

    fun autoTier(): Tier = when {
        lowRam || ramMb < 3000 || cores <= 4 -> Tier.LOW
        ramMb < 6500 || cores <= 6 -> Tier.MID
        else -> Tier.HIGH
    }

    fun tier(): Tier = when (Prefs.perfMode) {
        1 -> Tier.LOW
        2 -> Tier.MID
        3 -> Tier.HIGH
        else -> autoTier()
    }

    fun profile(): Profile {
        val t = tier()
        val base = when (t) {
            Tier.LOW -> Profile(t, (cores / 4).coerceIn(1, 2), "superfast", "ref=1:rc-lookahead=8:bframes=1", 2, 1)
            Tier.MID -> Profile(t, (cores / 2).coerceIn(2, 4), "veryfast", "ref=2:rc-lookahead=15", 4, 2)
            Tier.HIGH -> Profile(t, cores.coerceIn(2, 8), "faster", "", 8, 3)
        }
        return if (Prefs.parallel in 1..3) base.copy(parallel = Prefs.parallel) else base
    }

    fun describe(): String {
        val p = profile()
        val gb = String.format("%.1f", ramMb / 1024.0)
        val mode = if (Prefs.perfMode == 0) "Auto" else "Manual"
        return "$mode · ${p.tier.name.lowercase().replaceFirstChar { it.uppercase() }} profile\n" +
            "$cores cores · $gb GB RAM" + (if (lowRam) " · low-RAM device" else "") + "\n" +
            "Encoder threads ${p.threads} · preset ${p.preset} · ${p.parallel} task(s) at once · ${p.fragments} download connections"
    }
}
