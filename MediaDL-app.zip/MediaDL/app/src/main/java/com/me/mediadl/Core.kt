package com.me.mediadl

import android.app.Application
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.core.content.ContextCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** Task queue: runs downloads and conversions, adapts to the device profile. */
object Core {
    lateinit var app: Application
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val tasks = MutableStateFlow<List<Task>>(emptyList())

    private val running = ConcurrentHashMap<String, kotlinx.coroutines.Job>()
    private val dlSpecs = ConcurrentHashMap<String, Pair<String, DlOptions>>()
    private val cvSpecs = ConcurrentHashMap<String, Pair<Uri, ConvOptions>>()
    private val speedRe = Regex("at\\s+(\\S+/s)")

    fun init(a: Application) {
        app = a
        loadHistory()
    }

    // ---------- public API ----------

    fun enqueueDownload(info: MediaInfo, o: DlOptions): String {
        val id = UUID.randomUUID().toString().take(8)
        val title = o.name.ifBlank { info.title }
        dlSpecs[id] = info.url to o.copy(name = title)
        tasks.update { listOf(Task(id, TaskKind.DOWNLOAD, title, info.thumb, o.audio)) + it }
        kick()
        return id
    }

    fun enqueueConvert(uri: Uri, o: ConvOptions, title: String): String {
        val id = UUID.randomUUID().toString().take(8)
        cvSpecs[id] = uri to o
        val audioOut = o.ext in Ffmpeg.AUDIO_EXTS
        tasks.update { listOf(Task(id, TaskKind.CONVERT, title, "", audioOut)) + it }
        kick()
        return id
    }

    fun cancel(id: String) {
        upd(id) { if (it.active) it.copy(status = TaskStatus.CANCELED, note = "Canceled", progress = 0f) else it }
        try { YoutubeDL.getInstance().destroyProcessById(id) } catch (e: Throwable) { /* ignore */ }
        Ffmpeg.kill(id)
        running[id]?.cancel()
        saveHistory()
    }

    fun retry(id: String) {
        if (!dlSpecs.containsKey(id) && !cvSpecs.containsKey(id)) return
        upd(id) { it.copy(status = TaskStatus.QUEUED, progress = 0f, error = "", note = "") }
        kick()
    }

    fun canRetry(id: String) = dlSpecs.containsKey(id) || cvSpecs.containsKey(id)

    fun remove(id: String) {
        tasks.update { l -> l.filter { it.id != id || it.active } }
        dlSpecs.remove(id); cvSpecs.remove(id)
        saveHistory()
    }

    fun clearFinished() {
        tasks.update { l -> l.filter { it.active } }
        saveHistory()
    }

    // ---------- internals ----------

    private fun upd(id: String, f: (Task) -> Task) {
        tasks.update { l -> l.map { if (it.id == id) f(it) else it } }
    }

    private fun status(id: String): TaskStatus? = tasks.value.firstOrNull { it.id == id }?.status

    private fun kick() {
        try {
            ContextCompat.startForegroundService(app, Intent(app, DownloadService::class.java))
        } catch (e: Exception) { /* service is only for notification + keep-alive */ }
        pump()
    }

    @Synchronized
    private fun pump() {
        val limit = Device.profile().parallel
        for (t in tasks.value.reversed()) {          // oldest first
            if (running.size >= limit) break
            if (t.status != TaskStatus.QUEUED || running.containsKey(t.id)) continue
            val dl = dlSpecs[t.id]
            val cv = cvSpecs[t.id]
            if (dl == null && cv == null) continue
            upd(t.id) { it.copy(status = TaskStatus.RUNNING, progress = -1f, note = "Starting…") }
            running[t.id] = scope.launch(Dispatchers.IO) {
                try {
                    if (dl != null) runDownload(t.id, dl.first, dl.second)
                    else if (cv != null) runConvert(t.id, cv.first, cv.second, t.title)
                } finally {
                    running.remove(t.id)
                    pump()
                }
            }
        }
    }

    private fun workDir(id: String): File {
        val base = app.externalCacheDir ?: app.cacheDir
        return File(base, "job_$id").apply { mkdirs() }
    }

    private fun durationMs(f: File): Long = try {
        val r = MediaMetadataRetriever()
        r.setDataSource(f.absolutePath)
        val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        r.release()
        d
    } catch (e: Exception) { 0L }

    private suspend fun runDownload(id: String, url: String, o: DlOptions) {
        val dir = workDir(id)
        try {
            Engine.ensure(app)
            val p = Device.profile()
            val req = YoutubeDLRequest(url)
            req.addOption("--no-playlist")
            req.addOption("--no-mtime")
            req.addOption("--retries", "5")
            req.addOption("--fragment-retries", "5")
            req.addOption("--socket-timeout", "20")
            req.addOption("-N", p.fragments.toString())
            req.addOption("-o", File(dir, "out.%(ext)s").absolutePath)
            if (Prefs.turbo) {
                req.addOption("--downloader", "libaria2c.so")
                req.addOption("--external-downloader-args", "aria2c:-x 8 -s 8 -k 1M")
            }
            if (o.audio) {
                req.addOption("-f", "ba[ext=m4a]/ba/b")
                req.addOption("-x")
                req.addOption("--audio-format", o.audioFmt)
                req.addOption("--audio-quality", "${o.kbps}K")
            } else {
                val h = if (o.compress) minOf(if (o.height > 0) o.height else 720, 720) else o.height
                val hf = if (h > 0) "[height<=$h]" else ""
                req.addOption("-f", "bv*$hf[ext=mp4]+ba[ext=m4a]/b$hf[ext=mp4]/bv*$hf+ba/b$hf/b")
                req.addOption("--merge-output-format", "mp4")
            }

            YoutubeDL.getInstance().execute(req, id) { pr, eta, line ->
                val sp = speedRe.find(line)?.groupValues?.get(1)
                upd(id) {
                    it.copy(
                        progress = (pr / 100f).coerceIn(0f, 1f),
                        note = buildString {
                            append("Downloading")
                            if (sp != null) append(" · $sp")
                            if (eta > 0) append(" · ${eta}s left")
                        }
                    )
                }
            }

            var file = dir.listFiles()
                ?.filter { it.isFile && it.name.startsWith("out.") && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                ?.maxByOrNull { it.length() }
                ?: throw IOException("Download finished but no file was produced")

            if (o.compress && !o.audio) {
                upd(id) { it.copy(progress = 0f, note = "Compressing…") }
                val out = File(dir, "compressed.mp4")
                val args = Ffmpeg.buildArgs(app, file.absolutePath, out.absolutePath, "mp4", true, 1, 128)
                val dur = durationMs(file)
                Ffmpeg.run(app, id, args, dur) { f ->
                    upd(id) { it.copy(progress = f, note = "Compressing… ${(f * 100).toInt()}%") }
                }
                file = out
            }
            upd(id) { it.copy(progress = -1f, note = "Saving…") }
            finishSave(id, file, o.name, o.audio)
        } catch (e: Exception) {
            handleFail(id, e)
        } finally {
            dir.deleteRecursively()
        }
    }

    private suspend fun runConvert(id: String, uri: Uri, o: ConvOptions, title: String) {
        val dir = workDir(id)
        try {
            Engine.ensure(app)
            if (!Ffmpeg.locate(app)) throw IOException("ffmpeg engine not found. Re-run setup in Settings.")
            val cr = app.contentResolver
            val mime = cr.getType(uri) ?: ""
            val audioIn = mime.startsWith("audio")
            val inExt = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "bin"
            val inp = File(dir, "in.$inExt")

            val size = try { cr.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L } catch (e: Exception) { -1L }
            if (size > 0 && dir.usableSpace < size * 2 + 50_000_000L) {
                throw IOException("Not enough free storage for this file")
            }
            upd(id) { it.copy(progress = -1f, note = "Preparing file…") }
            val ins = cr.openInputStream(uri) ?: throw IOException("Can't read the selected file")
            ins.use { i -> inp.outputStream().use { out -> i.copyTo(out, 1 shl 16) } }

            val compress = o.mode == ConvMode.COMPRESS
            val outExt = if (compress) (if (audioIn) "m4a" else "mp4") else o.ext
            if (!compress && audioIn && outExt !in Ffmpeg.AUDIO_EXTS) {
                throw IOException("Audio files can only be converted to audio formats")
            }
            val out = File(dir, "out.$outExt")
            val dur = durationMs(inp)
            upd(id) { it.copy(progress = if (dur > 0) 0f else -1f, note = "Converting…") }
            val args = Ffmpeg.buildArgs(app, inp.absolutePath, out.absolutePath, outExt, compress, o.level, o.kbps)
            Ffmpeg.run(app, id, args, dur) { f ->
                upd(id) { it.copy(progress = f, note = "Converting… ${(f * 100).toInt()}%") }
            }
            upd(id) { it.copy(progress = -1f, note = "Saving…") }
            finishSave(id, out, o.name.ifBlank { title.substringBeforeLast('.') }, outExt in Ffmpeg.AUDIO_EXTS)
        } catch (e: Exception) {
            handleFail(id, e)
        } finally {
            dir.deleteRecursively()
        }
    }

    private fun finishSave(id: String, file: File, name: String, audio: Boolean) {
        val fn = Util.cleanName(name) + "." + file.extension
        val uri = Saver.save(app, file, fn, audio)
        if (status(id) == TaskStatus.CANCELED) return
        upd(id) {
            it.copy(
                status = TaskStatus.DONE, progress = 1f, audio = audio,
                note = "Saved to " + (if (audio) "Music" else "Movies"),
                outName = fn, outUri = uri
            )
        }
        saveHistory()
        Notifier.done(app, fn, true)
    }

    private fun handleFail(id: String, e: Exception) {
        if (status(id) == TaskStatus.CANCELED) return
        val msg = Util.friendly(e)
        upd(id) { it.copy(status = TaskStatus.ERROR, error = msg, progress = 0f) }
        saveHistory()
        Notifier.done(app, tasks.value.firstOrNull { it.id == id }?.title ?: "Task", false, msg)
    }

    // ---------- history ----------

    private fun saveHistory() {
        try {
            val arr = JSONArray()
            tasks.value.filter { !it.active }.take(60).forEach { t ->
                arr.put(
                    JSONObject().put("id", t.id).put("kind", t.kind.name).put("title", t.title)
                        .put("thumb", t.thumb).put("audio", t.audio).put("status", t.status.name)
                        .put("outName", t.outName).put("outUri", t.outUri)
                        .put("error", t.error).put("time", t.time)
                )
            }
            Prefs.history = arr.toString()
        } catch (e: Exception) { /* ignore */ }
    }

    private fun loadHistory() {
        try {
            val arr = JSONArray(Prefs.history)
            val l = ArrayList<Task>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                l.add(
                    Task(
                        id = o.getString("id"),
                        kind = TaskKind.valueOf(o.getString("kind")),
                        title = o.getString("title"),
                        thumb = o.optString("thumb"),
                        audio = o.optBoolean("audio"),
                        status = TaskStatus.valueOf(o.getString("status")),
                        progress = 1f,
                        outName = o.optString("outName"),
                        outUri = o.optString("outUri"),
                        error = o.optString("error"),
                        time = o.optLong("time")
                    )
                )
            }
            tasks.value = l
        } catch (e: Exception) { /* ignore */ }
    }

    fun clearTemp(): Int {
        if (tasks.value.any { it.active }) return -1
        val base = app.externalCacheDir ?: app.cacheDir
        var n = 0
        base.listFiles { f -> f.name.startsWith("job_") }?.forEach { it.deleteRecursively(); n++ }
        return n
    }
}
