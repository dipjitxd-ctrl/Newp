package com.me.mediadl

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Device.init(this)
        Core.init(this)
        Notifier.channels(this)
    }
}
