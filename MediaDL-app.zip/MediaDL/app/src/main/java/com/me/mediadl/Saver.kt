package com.me.mediadl

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.IOException

/** Copies a finished file into the public Movies / Music folders. */
object Saver {
    fun save(ctx: Context, src: File, displayName: String, audio: Boolean): String {
        val mime = Util.mimeOf(src.extension)
        if (Build.VERSION.SDK_INT >= 29) {
            val col: Uri = if (audio)
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            else
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, if (audio) "Music" else "Movies")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(col, cv) ?: throw IOException("Could not create file in gallery")
            try {
                ctx.contentResolver.openOutputStream(uri)!!.use { out ->
                    src.inputStream().use { it.copyTo(out, 1 shl 16) }
                }
            } catch (e: Exception) {
                ctx.contentResolver.delete(uri, null, null)
                throw e
            }
            cv.clear()
            cv.put(MediaStore.MediaColumns.IS_PENDING, 0)
            ctx.contentResolver.update(uri, cv, null, null)
            return uri.toString()
        } else {
            val dir = Environment.getExternalStoragePublicDirectory(
                if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
            )
            dir.mkdirs()
            var target = File(dir, displayName)
            var n = 1
            while (target.exists()) {
                target = File(dir, displayName.substringBeforeLast('.') + " ($n)." + displayName.substringAfterLast('.'))
                n++
            }
            src.inputStream().use { i -> target.outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
            MediaScannerConnection.scanFile(ctx, arrayOf(target.absolutePath), null, null)
            return Uri.fromFile(target).toString()
        }
    }
}
