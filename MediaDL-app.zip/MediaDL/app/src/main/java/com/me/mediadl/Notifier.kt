package com.me.mediadl

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object Notifier {
    const val CH_PROGRESS = "progress"
    const val CH_DONE = "done"

    fun channels(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CH_PROGRESS, "Active tasks", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_DONE, "Finished", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }

    fun openApp(c: Context): PendingIntent =
        PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    fun done(c: Context, title: String, ok: Boolean, msg: String = "") {
        val n = NotificationCompat.Builder(c, CH_DONE)
            .setSmallIcon(if (ok) android.R.drawable.stat_sys_download_done else android.R.drawable.stat_notify_error)
            .setContentTitle(if (ok) "Saved" else "Failed")
            .setContentText(if (ok) title else "$title — $msg")
            .setAutoCancel(true)
            .setContentIntent(openApp(c))
            .build()
        try {
            NotificationManagerCompat.from(c).notify((title + System.nanoTime()).hashCode(), n)
        } catch (e: SecurityException) { /* notifications not allowed */ }
    }
}
