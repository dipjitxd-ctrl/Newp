package com.me.mediadl

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.URL

class ShareActivity : Activity() {
    private val server = "http://127.0.0.1:5000"
    private val blue = Color.parseColor("#1E88E5")
    private val grey = Color.parseColor("#757575")
    private val green = Color.parseColor("#2E7D32")
    private val red = Color.parseColor("#C62828")
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val audioRates = listOf(64, 96, 128, 192, 256, 320)

    private var alive = true
    private var url = ""
    private var heights: List<Int> = emptyList()
    private var jobId: String? = null
    private var finished = false

    private lateinit var nameEdit: EditText
    private lateinit var rbVideo: RadioButton
    private lateinit var rbAudio: RadioButton
    private lateinit var spFormat: Spinner
    private lateinit var spQuality: Spinner
    private lateinit var tvQuality: TextView
    private lateinit var cbCompress: CheckBox
    private lateinit var tvStatus: TextView
    private lateinit var bar: ProgressBar
    private lateinit var btnOk: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val text = intent?.getStringExtra(Intent.EXTRA_TEXT) ?: ""
        val m = Regex("https?://\\S+").find(text)
        if (m == null) {
            Toast.makeText(this, "No link found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        url = m.value
        buildUi()
        fetchInfo()
    }

    override fun onDestroy() {
        alive = false
        super.onDestroy()
    }

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 14f
        setTextColor(grey)
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#66000000"))
        root.setOnClickListener { finish() }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            elevation = dp(12).toFloat()
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(4).toFloat()
            }
        }

        // ---- header ----
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(blue)
            setPadding(dp(20), 0, dp(20), 0)
        }
        val back = TextView(this).apply {
            text = "\u2190"
            textSize = 28f
            setTextColor(Color.WHITE)
            setOnClickListener { finish() }
        }
        val title = TextView(this).apply {
            text = "Download"
            textSize = 24f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(24), 0, 0, 0)
        }
        btnOk = TextView(this).apply {
            text = "OK"
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), dp(12), 0, dp(12))
            setOnClickListener { onOk() }
        }
        header.addView(back)
        header.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(btnOk)
        card.addView(header, LinearLayout.LayoutParams(MATCH, dp(64)))

        // ---- body ----
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(18))
        }
        body.addView(label("Filename"))
        nameEdit = EditText(this).apply {
            textSize = 20f
            setTextColor(Color.BLACK)
            hint = "Fetching name\u2026"
            setSingleLine(false)
            maxLines = 3
        }
        body.addView(nameEdit, LinearLayout.LayoutParams(MATCH, WRAP))

        val group = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        rbVideo = RadioButton(this).apply {
            id = View.generateViewId(); text = "Video"; textSize = 18f
            setTextColor(Color.BLACK)
        }
        rbAudio = RadioButton(this).apply {
            id = View.generateViewId(); text = "Audio"; textSize = 18f
            setTextColor(Color.BLACK)
        }
        group.addView(rbVideo)
        group.addView(rbAudio)
        val gp = LinearLayout.LayoutParams(MATCH, WRAP)
        gp.topMargin = dp(14)
        body.addView(group, gp)

        val fp = LinearLayout.LayoutParams(MATCH, WRAP)
        fp.topMargin = dp(10)
        body.addView(label("Format"), fp)
        spFormat = Spinner(this)
        body.addView(spFormat, LinearLayout.LayoutParams(MATCH, WRAP))

        tvQuality = label("Quality")
        body.addView(tvQuality, fp)
        spQuality = Spinner(this)
        body.addView(spQuality, LinearLayout.LayoutParams(MATCH, WRAP))

        cbCompress = CheckBox(this).apply {
            text = "Compress (smaller file, like TikTok downloaders)"
            textSize = 16f
            setTextColor(Color.BLACK)
        }
        val cp = LinearLayout.LayoutParams(MATCH, WRAP)
        cp.topMargin = dp(10)
        body.addView(cbCompress, cp)

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
            progressTintList = ColorStateList.valueOf(blue)
        }
        val bp = LinearLayout.LayoutParams(MATCH, WRAP)
        bp.topMargin = dp(18)
        body.addView(bar, bp)

        tvStatus = TextView(this).apply {
            textSize = 15f
            setTextColor(grey)
            gravity = Gravity.CENTER
            text = "Fetching info\u2026"
        }
        val sp = LinearLayout.LayoutParams(MATCH, WRAP)
        sp.topMargin = dp(12)
        body.addView(tvStatus, sp)

        card.addView(body, LinearLayout.LayoutParams(MATCH, WRAP))

        val w = (resources.displayMetrics.widthPixels * 0.9f).toInt()
        root.addView(card, FrameLayout.LayoutParams(w, WRAP, Gravity.CENTER))
        setContentView(root)

        group.setOnCheckedChangeListener { _, _ -> refreshSpinners() }
        rbVideo.isChecked = true
        refreshSpinners()
    }

    private fun setSpinner(sp: Spinner, items: List<String>) {
        val ad = object : ArrayAdapter<String>(
            this, android.R.layout.simple_spinner_item, items
        ) {
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val t = super.getView(p, v, g) as TextView
                t.setTextColor(Color.BLACK); t.textSize = 18f
                return t
            }

            override fun getDropDownView(p: Int, v: View?, g: ViewGroup): View {
                val t = super.getDropDownView(p, v, g) as TextView
                t.setTextColor(Color.BLACK); t.textSize = 18f
                t.setPadding(dp(16), dp(14), dp(16), dp(14))
                return t
            }
        }
        sp.adapter = ad
        sp.setPopupBackgroundDrawable(ColorDrawable(Color.WHITE))
    }

    private fun refreshSpinners() {
        if (jobId != null) return
        if (rbVideo.isChecked) {
            setSpinner(spFormat, listOf("mp4"))
            cbCompress.visibility = View.VISIBLE
            tvQuality.text = "Quality"
            val items = if (heights.isEmpty()) listOf("Best") else heights.map { "${it}p" }
            setSpinner(spQuality, items)
            val idx = heights.indexOfFirst { it <= 1080 }
            if (idx > 0) spQuality.setSelection(idx)
        } else {
            setSpinner(spFormat, listOf("m4a", "mp3"))
            cbCompress.visibility = View.GONE
            cbCompress.isChecked = false
            tvQuality.text = "Bitrate"
            setSpinner(spQuality, audioRates.map { "${it}kbps" })
            spQuality.setSelection(2)
        }
    }

    private fun status(t: String, color: Int = grey) {
        tvStatus.text = t
        tvStatus.setTextColor(color)
    }

    private fun ui(f: () -> Unit) {
        if (alive) runOnUiThread { f() }
    }

    private fun errMsg(e: Exception) =
        if (e is ConnectException) "Server offline \u2014 run Server.py in Termux"
        else e.message ?: "Error"

    private fun http(method: String, path: String, body: String?): JSONObject {
        val c = URL(server + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 5000
        c.readTimeout = 120000
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val s = if (c.responseCode < 400) c.inputStream else c.errorStream
        return JSONObject(s.bufferedReader().use { it.readText() })
    }

    private fun fetchInfo() {
        Thread {
            try {
                val r = http("POST", "/info", JSONObject().put("url", url).toString())
                if (r.has("error")) throw Exception(r.getString("error"))
                val t = r.optString("title")
                val arr = r.optJSONArray("heights") ?: JSONArray()
                val hs = (0 until arr.length()).map { arr.getInt(it) }
                ui {
                    heights = hs
                    if (nameEdit.text.isEmpty()) nameEdit.setText(t)
                    refreshSpinners()
                    if (jobId == null) status("Ready")
                }
            } catch (e: Exception) {
                ui { status("\u26A0 " + errMsg(e), red) }
            }
        }.start()
    }

    private fun onOk() {
        if (finished) finish() else startDownload()
    }

    private fun lock(locked: Boolean) {
        listOf<View>(nameEdit, rbVideo, rbAudio, spFormat, spQuality, cbCompress).forEach {
            it.isEnabled = !locked
        }
    }

    private fun startDownload() {
        if (jobId != null) return
        val video = rbVideo.isChecked
        val fmt = spFormat.selectedItem as String
        val pos = spQuality.selectedItemPosition
        val q = if (video) heights.getOrElse(pos) { 0 } else audioRates[pos]
        val body = JSONObject()
            .put("url", url)
            .put("name", nameEdit.text.toString().trim())
            .put("kind", if (video) "video" else "audio")
            .put("format", fmt)
            .put("quality", q)
            .put("compress", video && cbCompress.isChecked)
            .toString()
        jobId = "pending"
        lock(true)
        bar.visibility = View.VISIBLE
        bar.progress = 0
        status("Download started\u2026", blue)
        Thread {
            try {
                val r = http("POST", "/download", body)
                if (r.has("error")) throw Exception(r.getString("error"))
                val id = r.getString("id")
                jobId = id
                poll(id)
            } catch (e: Exception) {
                ui { fail(errMsg(e)) }
            }
        }.start()
    }

    private fun poll(id: String) {
        try {
            while (alive) {
                Thread.sleep(1000)
                val s = http("GET", "/status/$id", null)
                val st = s.optString("status")
                val pct = s.optInt("percent", 0)
                ui {
                    when (st) {
                        "queued" -> status("Download started\u2026", blue)
                        "downloading" -> {
                            bar.progress = pct
                            status("Downloading\u2026 $pct%", blue)
                        }
                        "compressing" -> {
                            bar.progress = 100
                            status("Compressing\u2026 (almost done)", blue)
                        }
                        "processing" -> {
                            bar.progress = 100
                            status("Processing\u2026", blue)
                        }
                        "done" -> {
                            bar.progress = 100
                            finished = true
                            btnOk.text = "CLOSE"
                            status("\u2713 Download completed\n" + s.optString("file"), green)
                        }
                        "error" -> fail(s.optString("error"))
                    }
                }
                if (st == "done" || st == "error") break
            }
        } catch (e: Exception) {
            ui { fail(errMsg(e)) }
        }
    }

    private fun fail(msg: String) {
        jobId = null
        lock(false)
        bar.visibility = View.GONE
        btnOk.text = "RETRY"
        status("\u2717 $msg", red)
    }
}
