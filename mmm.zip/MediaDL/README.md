# Media DL
1. Push this folder to a GitHub repo (main branch). Actions builds the APK -> Actions tab -> run -> Artifacts -> MediaDL-apk.
2. Install the APK. It has no launcher icon; it only appears in the Share sheet (Share > More > Media DL).
3. In Termux: pkg install python ffmpeg && pip install flask yt-dlp (and pkg install aria2 for faster downloads) && termux-setup-storage && python Server.py
Videos -> /storage/emulated/0/Movies, audio -> /storage/emulated/0/Music
